﻿
namespace HeaterApp
{
    partial class CreationWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BrandBox = new System.Windows.Forms.TextBox();
            this.ModelBox = new System.Windows.Forms.TextBox();
            this.ModesBox = new System.Windows.Forms.ComboBox();
            this.GenerateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BrandBox
            // 
            this.BrandBox.Location = new System.Drawing.Point(65, 46);
            this.BrandBox.Name = "BrandBox";
            this.BrandBox.Size = new System.Drawing.Size(100, 23);
            this.BrandBox.TabIndex = 0;
            this.BrandBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ModelBox
            // 
            this.ModelBox.Location = new System.Drawing.Point(65, 99);
            this.ModelBox.Name = "ModelBox";
            this.ModelBox.Size = new System.Drawing.Size(100, 23);
            this.ModelBox.TabIndex = 1;
            this.ModelBox.TextChanged += new System.EventHandler(this.ModelBox_TextChanged);
            // 
            // ModesBox
            // 
            this.ModesBox.AutoCompleteCustomSource.AddRange(new string[] {
            "",
            "Simple Heating",
            "Timer",
            "Air Humidification",
            "Turbo Mode"});
            this.ModesBox.FormattingEnabled = true;
            this.ModesBox.Items.AddRange(new object[] {
            "Simple Heating",
            "Timer",
            "Air Humidification",
            "Turbo Mode"});
            this.ModesBox.Location = new System.Drawing.Point(65, 156);
            this.ModesBox.Name = "ModesBox";
            this.ModesBox.Size = new System.Drawing.Size(121, 23);
            this.ModesBox.TabIndex = 2;
            // 
            // GenerateButton
            // 
            this.GenerateButton.Location = new System.Drawing.Point(210, 197);
            this.GenerateButton.Name = "GenerateButton";
            this.GenerateButton.Size = new System.Drawing.Size(75, 23);
            this.GenerateButton.TabIndex = 3;
            this.GenerateButton.Text = "Generate";
            this.GenerateButton.UseVisualStyleBackColor = true;
            this.GenerateButton.Click += new System.EventHandler(this.GenerateButton_Click);
            // 
            // CreationWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 246);
            this.Controls.Add(this.GenerateButton);
            this.Controls.Add(this.ModesBox);
            this.Controls.Add(this.ModelBox);
            this.Controls.Add(this.BrandBox);
            this.Name = "CreationWindow";
            this.Text = "CreationWindow";
            this.Load += new System.EventHandler(this.CreationWindow_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox BrandBox;
        private System.Windows.Forms.TextBox ModelBox;
        private System.Windows.Forms.ComboBox ModesBox;
        private System.Windows.Forms.Button GenerateButton;
    }
}