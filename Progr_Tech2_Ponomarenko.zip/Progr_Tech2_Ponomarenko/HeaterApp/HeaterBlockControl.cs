﻿/*****************************************************/
/* Лабораторная работа № 2 */
/* Абстрактные сущности и связи между ними */
/* Задание 2 */
/* Выполнил студент гр. 525и Пономаренко М.Ю. */
/****************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLib2;

namespace HeaterApp
{
    public partial class HeaterBlockControl : UserControl
    {
        Heater heater;
        private int n;
        public HeaterBlockControl()
        {
            InitializeComponent();
            heater = new Heater();
        }

        public HeaterBlockControl(string brand)
        {
            InitializeComponent();
            heater = new Heater(brand);
        }

        public HeaterBlockControl(string brand, string model)
        {
            InitializeComponent();
            heater = new Heater(brand, model);
        }

        public HeaterBlockControl(string brand, string model, Modes mode)
        {
            InitializeComponent();
            heater = new Heater(brand, model, mode);
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            BrandModel.Text = heater.GetBrand() + " " + heater.GetModel() + " " + heater.serNum;
            TempBar.Value = heater.Temp;
            TempBox.Text = TempBar.Value.ToString();
            Switch.Text = heater.TurnState;
            Switch.BackColor = Color.Red;
            ModeSwitch.Text = heater.GetMode();
            ModeSwitch.Enabled = false;
            TempBar.Enabled = false;
            TempBox.Enabled = false;
            switch (heater.GetMode())
            {
                case "SimpleHeating": n = 0;
                    break;
                case "Timer": n = 1;
                    break;
                case "AirHumidification": n = 2;
                    break;
                case "TurboMode": n = 3;
                    break;
            }
        }

        private void Switch_Click(object sender, EventArgs e)
        {
            heater.SwitchON_OFF();
            if (heater.TurnState == "ON")
            {
                Switch.Text = heater.TurnState;
                Switch.BackColor = Color.Green;
                ModeSwitch.Enabled = true;
                TempBar.Enabled = true;
                TempBox.Enabled = true;
            }
            else
            {
                Switch.Text = heater.TurnState;
                Switch.BackColor = Color.Red;
                ModeSwitch.Enabled = false;
                TempBar.Enabled = false;
                TempBox.Enabled = false;
            }
        }

        private void ModeSwitch_Click(object sender, EventArgs e)
        {
            if (n == 3) n = -1;
            heater.ChooseMode((Modes)(++n));
            ModeSwitch.Text = heater.GetMode();
            if (n == 2 || n == 3)
                TempBar.Enabled = false;
            else TempBar.Enabled = true;
        }

        private void TempBar_Scroll(object sender, EventArgs e)
        {
            heater.TempSet(TempBar.Value);
            TempBox.Text = heater.Temp.ToString();
        }
    }
}
