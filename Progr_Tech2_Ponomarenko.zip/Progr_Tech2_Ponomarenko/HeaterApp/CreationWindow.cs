﻿/*****************************************************/
/* Лабораторная работа № 2 */
/* Абстрактные сущности и связи между ними */
/* Задание 2 */
/* Выполнил студент гр. 525и Пономаренко М.Ю. */
/****************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HeaterApp
{
    public partial class CreationWindow : Form
    {
        private string brand, model;
        private int mode;

        public int CrMode()
        {
            return mode;
        }

        public string CrBrand()
        {
            return brand;
        }

        public string CrModel()
        {
            return model;
        }
        public CreationWindow()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (BrandBox.Text != "")
                ModelBox.Enabled = true;
            else
                ModelBox.Enabled = false;
        }

        private void CreationWindow_Load(object sender, EventArgs e)
        {
            ModelBox.Enabled = false;
            ModesBox.Enabled = false;
            ModesBox.SelectedIndex = 0;
        }

        private void ModelBox_TextChanged(object sender, EventArgs e)
        {
            if (ModelBox.Text != "")
                ModesBox.Enabled = true;
            else ModesBox.Enabled = false;
        }

        private void GenerateButton_Click(object sender, EventArgs e)
        {
            brand = BrandBox.Text;
            model = ModelBox.Text;
            mode = ModesBox.SelectedIndex;
            Close();
        }
      
        
    }
}
