﻿/*****************************************************/
/* Лабораторная работа № 2 */
/* Абстрактные сущности и связи между ними */
/* Задание 2 */
/* Выполнил студент гр. 525и Пономаренко М.Ю. */
/****************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLib2; 

namespace HeaterApp
{
    public partial class Form1 : Form
    {
        private static int num;
        List<HeaterBlockControl> blocks = new List<HeaterBlockControl>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreationWindow cw = new CreationWindow();
            cw.ShowDialog();
            if (cw.CrBrand() == "")
                blocks.Add(new HeaterBlockControl());
            if (cw.CrModel() == "")
                blocks.Add(new HeaterBlockControl(cw.CrBrand()));
            if (cw.CrMode() == 0)
                blocks.Add(new HeaterBlockControl(cw.CrBrand(), cw.CrModel()));
            if (cw.CrMode() != 0)
                blocks.Add(new HeaterBlockControl(cw.CrBrand(), cw.CrModel(), (Modes)cw.CrMode()));
            Controls.Add(blocks[num]);
            blocks[num].Left += blocks[num].Width*num;
            num++;
            if (num == 5)
                CreateButton.Enabled = false;
           
        }
    }
}
