﻿
namespace HeaterApp
{
    partial class HeaterBlockControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Switch = new System.Windows.Forms.Button();
            this.ModeSwitch = new System.Windows.Forms.Button();
            this.TempBar = new System.Windows.Forms.TrackBar();
            this.TempBox = new System.Windows.Forms.TextBox();
            this.BrandModel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TempBar)).BeginInit();
            this.SuspendLayout();
            // 
            // Switch
            // 
            this.Switch.Location = new System.Drawing.Point(16, 83);
            this.Switch.Name = "Switch";
            this.Switch.Size = new System.Drawing.Size(75, 23);
            this.Switch.TabIndex = 0;
            this.Switch.Text = "button1";
            this.Switch.UseVisualStyleBackColor = true;
            this.Switch.Click += new System.EventHandler(this.Switch_Click);
            // 
            // ModeSwitch
            // 
            this.ModeSwitch.Location = new System.Drawing.Point(16, 60);
            this.ModeSwitch.Name = "ModeSwitch";
            this.ModeSwitch.Size = new System.Drawing.Size(164, 23);
            this.ModeSwitch.TabIndex = 1;
            this.ModeSwitch.Text = "button2";
            this.ModeSwitch.UseVisualStyleBackColor = true;
            this.ModeSwitch.Click += new System.EventHandler(this.ModeSwitch_Click);
            // 
            // TempBar
            // 
            this.TempBar.Location = new System.Drawing.Point(12, 127);
            this.TempBar.Maximum = 75;
            this.TempBar.Name = "TempBar";
            this.TempBar.Size = new System.Drawing.Size(104, 45);
            this.TempBar.TabIndex = 5;
            this.TempBar.Scroll += new System.EventHandler(this.TempBar_Scroll);
            // 
            // TempBox
            // 
            this.TempBox.Enabled = false;
            this.TempBox.Location = new System.Drawing.Point(16, 166);
            this.TempBox.Name = "TempBox";
            this.TempBox.Size = new System.Drawing.Size(100, 23);
            this.TempBox.TabIndex = 6;
            // 
            // BrandModel
            // 
            this.BrandModel.AutoSize = true;
            this.BrandModel.Location = new System.Drawing.Point(3, 10);
            this.BrandModel.Name = "BrandModel";
            this.BrandModel.Size = new System.Drawing.Size(38, 15);
            this.BrandModel.TabIndex = 7;
            this.BrandModel.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Temperature";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Mode";
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BrandModel);
            this.Controls.Add(this.TempBox);
            this.Controls.Add(this.TempBar);
            this.Controls.Add(this.ModeSwitch);
            this.Controls.Add(this.Switch);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(183, 192);
            this.Load += new System.EventHandler(this.UserControl1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TempBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Switch;
        private System.Windows.Forms.Button ModeSwitch;
        private System.Windows.Forms.TrackBar TempBar;
        private System.Windows.Forms.TextBox TempBox;
        private System.Windows.Forms.Label BrandModel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}
