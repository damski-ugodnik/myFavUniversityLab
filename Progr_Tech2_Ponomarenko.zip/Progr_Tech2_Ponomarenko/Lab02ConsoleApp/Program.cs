﻿/*****************************************************/
/* Лабораторная работа № 2 */
/* Абстрактные сущности и связи между ними */
/* Задание 2 */
/* Выполнил студент гр. 525и Пономаренко М.Ю. */
/****************************************************/
using System;
using MyClassLib2;
using System.Collections.Generic;
namespace Lab02ConsoleApp
{
    class Program
    {
        static List<Heater> gadgets = new List<Heater>();
        static void Main(string[] args)
        {
        int choice;
            for (; ; )
            {
                Console.WriteLine("1 - Create new Heater\n" +
                    "2 - Show Heaters");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        CreateHeater();
                        break;
                    case 2:
                        {
                            if(gadgets.Count==0)
                            {
                                Console.WriteLine("Create at least one unit\n");
                                break;
                            }
                          l:ShowHeaters();
                            Console.WriteLine("0 - return\n" +
                                "*number of unit* - manipulate");
                            int ch = int.Parse(Console.ReadLine());
                            if (ch<=gadgets.Count&&ch>0)
                            {
                                Manipulate(ch-1);
                                break;
                            }
                            else if (ch == 0)
                            {
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Invalid input: Select existing unit");
                                goto l; 
                            }
                        }
                       
                }
            }
        }
        static void Manipulate(int unit)
        {
            Modes m = new Modes();
            for (; ; )
            {
                
               
                Console.WriteLine("Choose manipulation:\n" +
                    "1 - Turn ON/OFF\n" +
                    "2 - Change Mode\n" +
                    "3 - Set Temperature\n" +
                    "0 - Return");
                int choice = int.Parse(Console.ReadLine());
                if (gadgets[unit].TurnState == "OFF" && choice >1)
                {
                    Console.WriteLine("Turn the Heater ON first\n");
                    continue;
                }
                switch (choice)
                {
                    case 0: return;
                    case 1:
                        {
                            gadgets[unit].SwitchON_OFF();
                            Console.WriteLine("Turned {0}", gadgets[unit].TurnState);
                        }
                        break;
                    case 2:
                        {
                            Console.WriteLine("Modes:");
                            for (int i = 0; i < Enum.GetNames(m.GetType()).Length; i++)
                            {
                                Console.WriteLine(string.Format("{0} - {1}", i + 1, Enum.GetName(m.GetType(), i)));
                            }
                            Console.Write("Choose mode: ");
                            gadgets[unit].ChooseMode((Modes)int.Parse(Console.ReadLine()) - 1);
                            Console.WriteLine("Mode set");
                        }
                        break;
                    case 3:
                        {
                            if (gadgets[unit].TempSet(0) == -1)
                            {
                                Console.WriteLine("You can change temperature only in Simple Heating and Timer Mode");
                            }
                            else
                            {
                                Console.WriteLine("Insert temperature value [0 - 75]");
                                int t;
                                for (; ; )
                                {
                                    if (!int.TryParse(Console.ReadLine(), out t))
                                    {
                                        Console.WriteLine("Invalid input");
                                        continue;
                                    }
                                    if (gadgets[unit].TempSet(t) == -1)
                                    {
                                        Console.WriteLine("Insert correct temperature [0 - 75]");
                                        continue;
                                    }
                                    Console.WriteLine("Temperature set");
                                    break;
                                }
                            }
                        }
                        break;
                }
            }
        }
       static void ShowHeaters()
        {
           
           for(int i = 0;i<gadgets.Count;i++)
            {
                Console.WriteLine("{4}) brand: {0}; model: {1};serial number: {6}; state: {2}; mode: {3}; temperature: {5} degrees C", gadgets[i].GetBrand().ToUpper(), gadgets[i].GetModel().ToUpper(), gadgets[i].TurnState, gadgets[i].GetMode(),i+1, gadgets[i].Temp, gadgets[i].serNum);
            }
        }
        static void CreateHeater()
        {
            {
                Console.Write("Insert brand: ");
                string brand = Console.ReadLine();
                if (brand.Length == 0)
                {
                    gadgets.Add(new Heater());
                    return;
                }
                Console.Write("Insert model: ");
                string model = Console.ReadLine();
                if (model.Length == 0)
                {
                    gadgets.Add(new Heater(brand));
                    return;
                }
                Console.Write("Insert starting mode: \n" +
                    "0 - Simple Heating\n" +
                    "1 - Timer\n" +
                    "2 - Air Humidification\n" +
                    "3 - Turbo Mode\n" +
                    "Choice:");
                int mode;
                if (!int.TryParse(Console.ReadLine(), out mode))
                {
                    gadgets.Add(new Heater(brand, model));
                    return;
                }
                gadgets.Add(new Heater(brand, model, (Modes)mode));
            }
        }

    }
}
