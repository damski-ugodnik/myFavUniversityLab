﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyClassLib2
{
    public enum Modes
    {
        SimpleHeating,
        Timer,
        AirHumidification,
        TurboMode
    }
}