﻿/*****************************************************/
/* Лабораторная работа № 2 */
/* Абстрактные сущности и связи между ними */
/* Задание 2 */
/* Выполнил студент гр. 525и Пономаренко М.Ю. */
/****************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyClassLib2
{
    public class Heater
    {
        /// <summary></summary>
        private readonly string brand;
        private readonly string model;
        private Modes mode;
        private bool state;
        static private int gadgetsNum;
        private int temp;
        private string serialNum;
        /// <summary>
        /// Конструктор класса для параметров по умолчанию
        ///  brand = "Unknown"
       /// model = "Unknown"
        /// </summary>
        public Heater()
        {
            brand = "Unknown";
            model = "Unknown";
            state = false;
            temp = 25;
            gadgetsNum++;
        }
        /// <summary>
        /// Конструктор класса с указанием только бренда, остальные параметры по умолчанию
        /// model = "Unknown"
        /// </summary>
        /// <param name="brandSet"></param>
        public Heater(string brandSet) : this()
        {
            brand = brandSet;
        }
        /// <summary>
        /// Конструктор класса с указанием бреда и модели
        /// </summary>
        /// <param name="brandSet"></param>
        /// <param name="modelSet"></param>
        public Heater(string brandSet, string modelSet):this(brandSet)
        {
            model = modelSet;
        }
        /// <summary>
        /// Конструктор класса с указанием бренда модели и начального режима
        /// </summary>
        /// <param name="brandSet"></param>
        /// <param name="modelSet"></param>
        /// <param name="modeSet"></param>
        public Heater(string brandSet, string modelSet, Modes modeSet):this(brandSet,modelSet)
        {
            mode = modeSet;
        }
        /// <summary>
        /// Количество экземпляров класса
        /// </summary>
        static public int gNum
        {
            get { return gadgetsNum; }
        }
        /// <summary>
        /// Серийный номер экземпляра класса
        /// </summary>
        public string serNum
        {
            get
            {
                return string.Format("{0:D4}",gadgetsNum);
            }
        }
        /// <summary>
        /// Состояние прибора - Включён/Выключен
        /// </summary>
        public string TurnState
        {
            get
            {
                if (state) return "ON";
                else return "OFF";
            }
        }

      /// <summary>
      /// Метод выбора режима работы
      /// </summary>
      /// <param name="setMode"></param>

        public void ChooseMode(Modes setMode)
        {
            mode = setMode;
        }
        /// <summary>
        /// Получение режима работы
        /// </summary>
        /// <returns></returns>
        public string GetMode()
        {
            return mode.ToString();
        }
        /// <summary>
        /// Функция включить/выключить: необходимо просто вызвать функцию
        /// </summary>
        public void SwitchON_OFF()
        {
            if (state)
                state = false;
            else
                state = true;
        
        }
        /// <summary>
        /// Мето получения бренда
        /// </summary>
        /// <returns></returns>
        public string GetBrand()
        {
            return brand;

        }
        /// <summary>
        /// Метод получения модели 
        /// </summary>
        /// <returns></returns>
        public string GetModel()
        {
            return model;

        }
        /// <summary>
        /// Метод установки температуры
        /// </summary>
        /// <param name="valueGot"></param>
        /// <returns></returns>
        public int TempSet(int valueGot)
        {
            if (mode == Modes.TurboMode || mode == Modes.AirHumidification || valueGot < 0 || valueGot>75)
                return -1;
            else
                return temp = valueGot;
        }
        /// <summary>
        /// Температура прибора
        /// </summary>
        public int Temp
        {
            get
            {
                return temp;
            }
        }
    }
}